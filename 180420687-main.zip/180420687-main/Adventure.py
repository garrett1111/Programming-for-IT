'''
Garrett & Michael
October 30, 2024
Adventure Inventory
'''

#Add items to the inventory
inventory_List = []

inventory_List.extend (["Big Mac", "Empty Pot", "Finger"])


print (inventory_List)

#View the inventory
def view_Inventory():
    for item in inventory_List:
        print("This is what you have in your inventory:", (inventory_List))

#Remove items from the inventory
def remove_from_Inventory():
    item = int( input ("Please select an item to remove:"))
    for item in inventory_List:
        if item = 0

    del item


view_Inventory()
remove_from_Inventory()

