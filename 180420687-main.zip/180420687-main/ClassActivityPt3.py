###
# Garrett & Michael
# Wednesday September 11 2024
# In Class Activity
###

'''
#Narrator#
print("You encounter an old man sitting on the razors edge of a mountain.")

#Old Man#
print("Hello Tarnished, what brings you all the way up here?")

#Tarnished#
print ("I am looking for the Elden Ring.")

#Old Man#
print ("Oh foul Tarnished, in search of the Elden Ring. Emboldened by the flame of ambition. ")
Tarnished = input ("What are you willing to sacrifice?")

#Tarnished#
print ("I am willing to sacrifice", Tarnished)

#Old Man#
print ("Good. Close to the river you will find a site of grace. There you will meet Melina. She will lead you from there.")

#Tarnished#
OldMan = input ("Before I leave, may I ask your name?")

#Old Man#
print ("They call me", OldMan)

#Narrator#
print ("The tarnished and", OldMan, "part their ways and with the tarnished willing to sacrifice", Tarnished, "he start his journey to become the Elden Lord")

#Narrator#
print ("After a resilient journey, the tarnished reaches the river at last. He sees Melina from a distance and approaches her.")

#Melina#
print ("Welcome Tarnished, what brings you all the way down here?")

#Tarnished#
print ("I desire to become the Elden Lord.")

#Melina#
print ("That's no easy feat. You need to have much preparation. What do you possess right now?")

#Tarnished#

ItemInHand = "Bare Hand"
print (f"Since I am just starting my journey I only possess {ItemInHand} but I'm willing to become stronger." )

#Melina#
print ("HA, you're going to need more than that. I can offer you some useful items my dear tarnished.")









Items = ["Runes", "Medallion", "Whistle"]

print ("0:", Items[0])
print ("1:", Items [1])
print ("2:", Items [2])


Item = int( input ("Please select a item from 0 to 2:"))


print (f"I take the {Items[Item]}")

print (f"Nice choice, I trust you so I am going to give you and extra hand")

Elements = ("Fire", "Water", "Wind")

print  ("0:", Elements[0], Items[Item])
print  ("1:", Elements[1], Items[Item])
print  ("2", Elements[2], Items[Item])

Element = int( input ("Splendid, now select an element to fuse it with"))

print(f"Now you have unlocked the {Elements[Element]} {Items[Item]}")

'''

inventory_List = []

inventory_List.append ("Finger")
print (inventory_List)




'''
def view_Inventory():
    for item in inventory_List:
        print(inventory_List)

def remove_from_Inventory():

'''







