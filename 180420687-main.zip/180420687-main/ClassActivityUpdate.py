###
# Garrett & Michael
# Wednesday October 9 2024
# In Class Activity
###

#Narrator#
print("You encounter an old man sitting on the razors edge of a mountain.")

#Old Man#
def Old_Man():
    print("Hello Tarnished, what brings you all the way up here?")
Old_Man ()
#Tarnished#
print ("I am looking for the Elden Ring.")

#Old Man#
print ("Oh foul Tarnished, in search of the Elden Ring. Emboldened by the flame of ambition. ")
Sacrifice = input ("What are you willing to sacrifice?")

#Tarnished#
print ("I am willing to sacrifice", Sacrifice)
#Old Man#
print ("Good. Close to the river you will find a site of grace. There you will meet Melina. She will lead you from there.")

#Tarnished#
OldMan = input ("Thank you. Before I leave, may I ask your name?")

#Old Man#
print ("They call me", OldMan)

#Narrator#
print ("The tarnished and", OldMan, "part their ways and with the tarnished willing to sacrifice", Sacrifice, "he start his journey to become the Elden Lord.")
#Narrator#
print ("After a resilient journey, the tarnished reaches the river at last. He sees Melina from a distance and approaches her.")
#Melina#
print ("Welcome Tarnished, what brings you all the way down here?")
#Tarnished#
print ("I desire to become the Elden Lord.")
#Melina#
print ("That's no easy feat. You need to have much preparation. What do you possess right now?")

#Tarnished#
ItemInHand = "Bare Hand"
print (f"Since I am just starting my journey I only possess {ItemInHand} but I'm willing to become stronger." )

#Melina#
print ("HA, you're going to need more than that. I can offer you some useful items my dear tarnished.")

#Items = ["Runes", "Medallion", "Whistle"]

#print ("0:", Items[0])
#print ("1:", Items [1])
#print ("2:", Items [2])


#Item = input ("Please select an item from 0 to 2:")

def items (Select):

    print ("Select one of the following choices:")
    print ("1. Runes")
    print ("2. Medallion")
    print ("3. Whistle")

    choice = int (input())
    if choice == 1:
            choiceOne = input ("Select one of the following choices:")
            print (f"You have chosen the {choiceOne}")

    elif choice == 2:
            choiceTwo = input ("Select one of the following choices:")
            print (f"You have chosen the {choiceTwo}")

    elif choice == 3:
            choiceThree = input ("Select one of the following choices:")
            print (f"You have chosen the {choiceThree}")
    else:
            print ("Please select again.")




    #Selection = int (input ("Please select an item from 0 to 2:"))
    Selection = input ("Please select an item from 0 to 2.")
    items(Select)



print ("I take the, Item, ")

print (f"Nice choice, I trust you so I am going to give you and extra hand.")

Elements = ("Fire", "Water", "Wind")

print  ("0:", Elements[0], Items[Item])
print  ("1:", Elements[1], Items[Item])
print  ("2", Elements[2], Items[Item])

Element = int( input ("Splendid, now select an element to fuse it with"))

print(f"Now you have unlock the {Elements[Element]} {Items[Item]}")
