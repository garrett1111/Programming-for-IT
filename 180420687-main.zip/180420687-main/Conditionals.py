#Conditionals
#September 25 2024

age = int(input ("enter your age:"))
if age >= 18:

    print ("we may proceed")

    if age >= 21:
        print ("you can drink and smoke and yes")

    else:
        print ("at least you can vote and join our military")


else:

    print ("good bye")

print ("good bye")

