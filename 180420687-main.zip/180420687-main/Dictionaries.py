'''
Dictionaries
October 28 2024
'''

def numToMonth (monthNumber):
    months = {1: "January", 2: "February", 3: "March", 4: "April", 5: "May",
              6: "June", 7: "July", 8: "August", 9: "September", 10: "October",
              11: "November", 12: "December"}

    for monthNum, monthWord in months.items():
        print (monthNum, monthWord)


    if monthNumber in months:
        return months [monthNumber]
    else:
        return None

print (numToMonth(0))

