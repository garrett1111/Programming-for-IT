#Wednesday October 2, 2024


def welcome ():
    print ("hello")
    print ("good day!")
    #return

def addThis (a, b, c):
    result = a + b + c
    print (result)
    #return

def multThis (a, b, c):
    result = a * b * c
    return result

welcome()
addThis (3, 5, 1)
x = 6
y = 9
z = 4
addThis (x, y, z)

answer = multThis(x, y, z)
print (answer)
