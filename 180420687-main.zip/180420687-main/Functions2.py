#Wednesday October 2, 2024


def calc_pay (rate, hours):
    if hours <= 40:
        result = rate * hours
    else:
        extratime = hours - 40
        overtime_rate = rate * 1.5
        result = rate * 40 + extratime * overtime_rate
    return result




print (calc_pay(17,42))

