def SayHello (name):
    print (f"Hello {name}!")
    return

def findGreatest (num1, num2, num3):
    if num2 > num1 and num2 > num3:
        great = num2
    elif num3 > num1 and num3 > num2:
        great = num3
    else:
        great = num1
    return great

print ("Welcome")
print ("What is your name?")
name = input ()
testname = "Alice"

SayHello (name)
findGreatest (3, 5 ,4)




