import random

def printInfo (sec, count, blank, guessed):
    print (sec)
    print (f"wrong guess: {count}")
    print ("used letters", guessed)
    print(blank)

def checkGuess(l, w):
    return (l, w)

def reveal (sec, blks, guess):
    for index in range (0, len(sec)):
        if sec [index] == guess:
            blks [index] = guess

def game():
    wordlist = ['hello', 'computer', 'water', 'wallet']
    blanks = []
    wrongCount = 0
    guessedLetters = []

    secret = random.choice(wordlist)
    for letter in secret:
        blanks.append('_')
    printInfo (secret, wrongCount, blanks, guessedLetters)

    while wrongCount < 6 and '_' in blanks:
        guessLetter = input ("enter a letter\n")
        


        guessedLetters.append(guessLetter)
        goodLetter = checkGuess (guessLetter, secret)
        if not goodLetter:
            wrongCount +=1
        else:
            reveal (secret, blanks, guessLetter)
        printInfo (secret, wrong)



game()
