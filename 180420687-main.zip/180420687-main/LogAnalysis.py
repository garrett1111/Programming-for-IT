'''

Garrett
Log Analysis
Monday November 4 2024

'''

import re
file1 = open("access_log")

requester = {}
resource = {}
res_by_req = {}

pattern = r"(^.*) - - .*GET (.*) HTTP"

for line in file1:
    matches = re.findall(pattern, line)
    if len(matches) > 0:
        tup = matches[0]
        req = tup[0]
        res = tup[1]
        print(req, res)

        if req in requester:
            requester[req] += 1
        else:
            requester[req] = 1

        if res in resource:
            resource[res] += 1
        else:
            resource[res] = 1

        if req in res_by_req:
            d = res_by_req[req]
            if res in d:
                d[res] += 1
            else:
                d[res] = 1
        else:
            res_by_req[req] = {res:1}

print(res_by_req)



largestCount = 0
largestRequester = ''

#Count for largest requester

for req in requester:
    if requester [req] > largestCount:
        largestCount = requester [req]
        largestRequester = req

print ('Largest Requester: ', largestRequester, 'Count: ', largestCount)

largestCount = 0
largestResource = ''

#Count for largest resource

for res in resource:
    if resource [res] > largestCount:
        largestCount = resource [res]
        largestResource = res

print ('Largest Resource: ', largestResource, 'Count: ', largestCount)



Most_Resource_By_Top_Requester = 0
Requested_Most = ' '

for req in res_by_req:
    if requester [req] > Most_Resource_By_Top_Requester:
        Most_Resource_By_Top_Requester = requester [req]
        Requested_Most = req

print(Requested_Most)



































































