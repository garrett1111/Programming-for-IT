#Practice

print ("Select one of the following choices:")
print ("1: say hello")
print ("2: tell a joke")
print ("3: say a fact")
print ("4: exit")

choice = int (input())

if choice == 1:
    name = input ("what is your name")
    print (f"hello {name}")

elif choice == 2:
    print ("I work at a place and no joke hahaha")

elif choice == 3:
    print ("The War of 1812 did not happen and was entirely made up. Just like this fact.")

elif choice == 4:
    print ("Goodbye")
    
else:
    print ("You have failed. Goodbye.")

