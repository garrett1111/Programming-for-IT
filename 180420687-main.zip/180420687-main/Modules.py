# October 9 2024
# Modules

from random import randint

def rollDice ():
    roll = randint (1,6) + randint (1,6)
    return roll
def instantWin (roll):
    if roll == 7 or roll == 11:
        return True
    else:
        return False

def instantLoss (roll):





