'''
Garrett Mulhall 00338291
October 30 2024
Box of Fun Project
Programming for IT
This is an interactive program that allows the user to play 3 different mini games. Have fun!
'''

#importing the random module
from random import randint

#This is the menu that will be presented to the user
def MainMenu ():
    print ("1- Ask the fortune teller. ")
    print ("2- Complete a Mad Lib. ")
    print ("3- Guess a number. ")
    print ("4- Quit. ")

#calling the function so it actually prints out
MainMenu()

#their choice will be casted to an integer
choice = int (input("Select one of the options: "))


#fortune teller function
def fortuneTeller ():

    Question = input ("What do you wish to ask the fortune teller? (Must be a yes or no question!) ")
    randNumb = randint (1,6)

    if randNumb == 1:
        message = "Yes"
    elif randNumb == 2:
        message = "No"
    elif randNumb == 3:
        message = "Possibly"
    elif randNumb == 4:
        message = "Without a doubt"
    elif randNumb == 5:
        message = "Never in a million years"
    else:
        message = "Ask your mother"

    print (f"This is what you asked: {Question}")
    print (f"This is what the fortune teller has answered: {message}")


#function for the Mad Lib
def madLib():

    noun = input ("Enter a noun: ")
    verb = input ("Enter a past tense verb: ")
    adverb = input ("Enter an adverb: ")
    adjective = input ("Enter an adjective: ")

    print (f"Once upon a time there was a(n) {noun}. This {noun} was unlike any other {noun} in the entire town. As he {adverb} {verb} along the sidewalk, he noticed something out of the ordinary. This normal day for the {noun} would end up turning into a(n) {adjective} one...")

#function for guessing a number
def guessNumber():

    secretNumber = randint (1,50)
    guesses = 1
    maxGuesses = 3
    userGuess = int (input("Guess the secret number that is between 1 and 50: "))

    while guesses < maxGuesses:

        if userGuess == secretNumber:
            print ("Wow! Nice guess! You got it right!")

        elif userGuess > secretNumber:
            guesses = guesses + 1
            print ("That is too high!")
            userGuess = int (input("Guess the secret number that is between 1 and 50: "))
        else:
            guesses = guesses + 1
            print ("That is too low!")
            userGuess = int (input("Guess the secret number that is between 1 and 50: "))

    print (f"We're going to be here all day at his rate! The secret number is {secretNumber}. Better luck next time!")


#Loop that will repeat the menu until user chooses to quit
while choice != 4:

    if choice == 1:
        fortuneTeller()
        MainMenu()
        choice = int (input("Select one of the options: "))

    elif choice == 2:
        madLib()
        MainMenu()
        choice = int (input("Select one of the options: "))

    elif choice == 3:
        guessNumber()
        MainMenu()
        choice = int (input("Select one of the options: "))
