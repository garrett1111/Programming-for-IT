'''

Garrett Mulhall 00338291
December 2 2024
Programming for IT
Final Project

'''

#importing random module
from random import randint

#file that stores usernames and passwords
open ('user_data.txt', 'w')

#file that stores action logs
open ('log.txt', 'w')

#user data dictionary
user_data = {}

#this function will show the main menu to the user
def display_main_menu ():
    print ('1: Login')
    print ('2: Create Account')
    print ('3: Quit')

#calling the main menu function
display_main_menu ()

choice = int (input('What would you like to do?'))

#reads from the file and loads data into a dictionary
def load_user_data ():
    with open ('user_data.txt', 'r') as user_file:
        users = user_file.readlines ()

        for line in users:
            line = line.strip()
            lines = line.split(' :: ')
            user_data.append (lines)

#saves data from the dictionary and appends it to the user_data file
def save_user_data ():
    with open ('user_data.txt', 'w') as file:
        file.write (str(user_data))

#function to create a new username
def create_username ():
    first_name = input ('Enter your first name: ')
    first_letter = first_name [0]
    family_name = input ('Enter your last name: ')
    rand_num = randint (1000,9999)
    print (f'Your username is {first_letter}{family_name}{rand_num}')

#function to login with an existing username
def get_username ():
    username = input ('Enter your username: ')
    print (f'{username} has been chosen as your username')

#function that checks if the password is valid
def test_valid_password ():
    encrypt_password ()

#password encryption function
def encrypt_password ():
    if len(password_1) < 7:
        print ('The password you entered is too short. Try again.')

    if char in password_1 == ["!", '@', '$', ':','?']:
        print ('Invalid password. Try again.')

    'i' == '!'
    'a' == '@'
    'S' == '$'
    'J' == '?'

#prompt the user for a password
def get_password ():
    attempts = 5

    while attempts > 0:
        password_1 = input('Enter a password (Cannot contain ! @ $ : or ?): ')
        password_2 = input('Please confirm the password: ')
        if password_1 == password_2:
            test_valid_password ()

#function that allows the user to update their password
def update_password ():
    updated_password = input('Enter a new password: ')
    user_data.update ({updated_password})

    with open ('user_data.txt', 'w') as updated_pass:
        updated_pass (str(user_data))
    print ('Password changed successfully')

#function to add a user
def add_user ():
    create_username ()
    get_password ()
    user_data.update ({username, password_1})

#check user function
def check_user ():
    if username in user_data:
        return True
    else:
        return False

#writing to the log
def write_to_log ():
    log = open ('log.txt', 'a')
    log.write ('OK')
    log.write ('BAD PASS')
    log.write ('NEW USER')
    log.write ('UPDATE')

#function to print the log to the screen
def print_log ():
    login_choice = int (input('What do you wish to do?'))
    print ('1: Print log')
    print ('2: Update Password')
    print ('3: Quit')

    logtxt = open ('log.txt')
    print (logtxt)

print_log ()

while choice != 3:

    if choice == 1:
        get_username ()
        check_user ()
        get_password ()

        if login_choice == 1:
            print_log ()

        elif login_choice == 2:
            update_password ()

        else:
            print ('Goodbye!')

    elif choice == 2:
        add_user ()
        get_password ()

    else:
        print ('Goodbye!')
