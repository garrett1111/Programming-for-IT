# Garrett Mulhall
# September 16 2024

word = "four"
shift = 5
newWord = ""

firstOrd = ord(word [0])
shiftedOrd = firstOrd + 1
shiftedChar = chr (shiftedOrd)

newWord = newWord + shiftedChar


shiftedChar = chr(ord(word[3]) + shift)


print (newWord)
