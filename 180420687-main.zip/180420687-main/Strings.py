'''
email = input ("Enter an email: ")

location = email.find ("@")
print (location)
print (email[:location])
host = (email[location+1:])
print (host)

hostList = host.split(".")
print (f"TLD = {hostList[-1]}")

'''
colors = ["red", "green", "blue"]
colors.append ("yellow")
othercolors = ["black", "white"]
colors.extend (othercolors)
colors.insert (1, "orange")

for c in colors:
    print (c)





