#Activity
#September 25 2024

wave = int (input ("Enter a wave:"))

if wave >= 389 and wave <= 449:
    print ("Violet")
elif wave >= 450 and wave <= 484:
    print ("Blue")
elif wave >= 485 and wave <= 499:
    print ("Cyan")
elif wave >= 500 and wave <= 564:
    print ("Green")
elif wave >= 565 and wave <= 589:
    print ("Yellow")
elif wave >= 590 and wave <= 624:
    print ("Orange")
elif wave >= 625 and wave <= 750:
    print ("Red")

else:
    print ("That is not a visible wave")


