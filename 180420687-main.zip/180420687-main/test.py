from random import randint

def guessNumber():

    secretNumber = randint (1,50)
    guesses = 1
    maxGuesses = 3
    userGuess = int (input("Guess the secret number that is between 1 and 50: "))

    while guesses < maxGuesses:


        if userGuess == secretNumber:
            print ("Wow! Nice guess! You got it right!")

        elif userGuess > secretNumber:
            guesses = guesses + 1
            print ("That is too high! Guess again.")
            userGuess = int (input("Guess the secret number that is between 1 and 50: "))

        else:
            guesses = guesses + 1
            print ("That is too low! Guess again.")
            userGuess = int (input("Guess the secret number that is between 1 and 50: "))

    print (f"We're going to be here all day at this rate! The secret number is {secretNumber}. Better luck next time!")

guessNumber ()
